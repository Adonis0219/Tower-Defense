using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MUpPanelManager : PanelManager
{
    private void Update()
    {
           
    }
}
